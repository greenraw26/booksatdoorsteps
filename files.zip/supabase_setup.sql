-- ============================================================
-- Books at Doorsteps — Database Setup
-- Run this once in Supabase: SQL Editor → New Query → paste all → Run
-- ============================================================

-- 1. PROFILES — extends Supabase's built-in auth.users with category info
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  category text not null check (category in ('publisher','school','individual','institution')),
  full_name text,
  organisation text,
  phone text,
  is_admin boolean default false,
  created_at timestamptz default now()
);

alter table profiles enable row level security;

create policy "Users can view their own profile"
  on profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on profiles for update
  using (auth.uid() = id);

create policy "Users can insert their own profile"
  on profiles for insert
  with check (auth.uid() = id);

create policy "Admins can view all profiles"
  on profiles for select
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));


-- 2. LISTINGS — publisher book submissions
create table listings (
  id uuid primary key default gen_random_uuid(),
  publisher_id uuid references profiles(id) on delete cascade,
  title text not null,
  category text,
  origin text check (origin in ('Indian','Foreign')),
  mrp numeric,
  price numeric,
  image_url text,
  description text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz default now()
);

alter table listings enable row level security;

create policy "Anyone can view approved listings"
  on listings for select
  using (status = 'approved');

create policy "Publishers can view their own listings"
  on listings for select
  using (auth.uid() = publisher_id);

create policy "Publishers can insert their own listings"
  on listings for insert
  with check (auth.uid() = publisher_id);

create policy "Admins can view all listings"
  on listings for select
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));

create policy "Admins can update any listing"
  on listings for update
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));


-- 3. BOOK REQUESTS — logged-in members requesting a title
create table book_requests (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid references profiles(id) on delete cascade,
  book_title text not null,
  notes text,
  status text not null default 'open' check (status in ('open','fulfilled','closed')),
  created_at timestamptz default now()
);

alter table book_requests enable row level security;

create policy "Members can view their own requests"
  on book_requests for select
  using (auth.uid() = requester_id);

create policy "Members can insert their own requests"
  on book_requests for insert
  with check (auth.uid() = requester_id);

create policy "Admins can view all book requests"
  on book_requests for select
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));

create policy "Admins can update book requests"
  on book_requests for update
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));


-- 4. CONTACT REQUESTS — open to everyone, no login needed
create table contact_requests (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  phone text,
  message text,
  created_at timestamptz default now()
);

alter table contact_requests enable row level security;

create policy "Anyone can submit a contact request"
  on contact_requests for insert
  with check (true);

create policy "Admins can view contact requests"
  on contact_requests for select
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.is_admin = true));


-- ============================================================
-- LAST STEP (do this AFTER you've signed up on the live site once):
-- Run this to make your own account the admin. Replace the email below
-- with the email you used to sign up.
-- ============================================================
-- update profiles set is_admin = true where id =
--   (select id from auth.users where email = 'your-email@example.com');
