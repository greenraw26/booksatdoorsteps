<?php
session_start();
require __DIR__ . '/backend/config.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Please enter both email and password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Portal Login – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body class="bg-soft">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm border-0 rounded-4">
          <div class="card-body p-4 p-lg-5">
            <div class="text-center mb-4">
              <div class="brand-badge mb-2 mx-auto">DD</div>
              <h3 class="fw-bold mb-1">
                Deepshikha <span class="text-primary">Portal</span>
              </h3>
              <p class="text-muted small mb-0">For distributors, schools & internal team</p>
            </div>
            <?php if ($error): ?>
              <div class="alert alert-danger small py-2"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="post" action="login.php">
              <div class="mb-3">
                <label class="form-label small">Email / User ID</label>
                <input type="text" name="email" class="form-control" required />
              </div>
              <div class="mb-3">
                <label class="form-label small">Password</label>
                <input type="password" name="password" class="form-control" required />
              </div>
              <div class="d-flex justify-content-between align-items-center mb-3 small">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="remember" />
                  <label class="form-check-label" for="remember">
                    Remember me
                  </label>
                </div>
                <span class="link-muted">Forgot password?</span>
              </div>
              <button type="submit" class="btn btn-primary w-100 rounded-pill py-2">
                Login
              </button>
            </form>
            <hr class="my-4" />
            <p class="small text-muted text-center mb-0">
              Demo login: admin@example.com / admin123
            </p>
          </div>
        </div>
        <p class="text-center small text-muted mt-3 mb-0">
          <a href="index.html" class="link-muted">← Back to website</a>
        </p>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
