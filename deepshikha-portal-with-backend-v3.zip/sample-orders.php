<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require __DIR__ . '/backend/config.php';

$status_filter = $_GET['status'] ?? 'all';
$type_filter = $_GET['type'] ?? 'all';

$sql = "SELECT * FROM sample_orders WHERE 1=1";
$params = [];
if ($status_filter !== 'all') {
    $sql .= " AND status = ?";
    $params[] = $status_filter;
}
if ($type_filter !== 'all') {
    $sql .= " AND type = ?";
    $params[] = $type_filter;
}
$sql .= " ORDER BY created_at DESC, id DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Sample Orders – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="d-flex dashboard-shell">
    <nav class="flex-shrink-0 p-3 border-end min-vh-100 sidebar">
      <a href="dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none sidebar-brand">
        <span class="brand-badge me-2">DD</span>
        <span class="fs-6 fw-bold">Deepshikha</span>
      </a>
      <hr />
      <ul class="nav nav-pills flex-column mb-auto small">
        <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
        <li><a href="orders-list.php" class="nav-link">Orders</a></li>
        <li><a href="sample-orders.php" class="nav-link active">Sample Orders</a></li>
      </ul>
      <hr />
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle small" data-bs-toggle="dropdown">
          <span class="me-2 avatar-circle"><?php echo strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?></span>
          <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin User'); ?></strong>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <main class="p-4 flex-grow-1 main-panel">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h1 class="h5 fw-bold mb-1">Sample Orders</h1>
          <p class="small text-muted mb-0">School / parent sample requests from DB</p>
        </div>
        <a href="sample-order-create.php" class="btn btn-primary btn-sm rounded-pill">+ New Sample Order</a>
      </div>

      <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body small">
          <form class="row g-2 align-items-end" method="get" action="sample-orders.php">
            <div class="col-md-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select form-select-sm">
                <option value="all" <?php echo $status_filter==='all'?'selected':''; ?>>All</option>
                <option value="pending" <?php echo $status_filter==='pending'?'selected':''; ?>>Pending</option>
                <option value="dispatched" <?php echo $status_filter==='dispatched'?'selected':''; ?>>Dispatched</option>
                <option value="delivered" <?php echo $status_filter==='delivered'?'selected':''; ?>>Delivered</option>
              </select>
            </div>
            <div class="col-md-3">
              <label class="form-label">Type</label>
              <select name="type" class="form-select form-select-sm">
                <option value="all" <?php echo $type_filter==='all'?'selected':''; ?>>All</option>
                <option value="school" <?php echo $type_filter==='school'?'selected':''; ?>>School</option>
                <option value="parent" <?php echo $type_filter==='parent'?'selected':''; ?>>Parent</option>
              </select>
            </div>
            <div class="col-md-2">
              <button class="btn btn-outline-primary btn-sm rounded-pill w-100" type="submit">Filter</button>
            </div>
          </form>
        </div>
      </div>

      <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-sm align-middle mb-0 small">
              <thead class="table-light">
                <tr>
                  <th>Sample No.</th>
                  <th>Requested By</th>
                  <th>Type</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($rows as $row):
                    $status = $row['status'];
                    $badgeClass = 'bg-secondary-subtle text-secondary';
                    if ($status === 'delivered') $badgeClass = 'bg-success-subtle text-success';
                    elseif ($status === 'dispatched') $badgeClass = 'bg-primary-subtle text-primary';
                    elseif ($status === 'pending') $badgeClass = 'bg-warning-subtle text-warning';
                ?>
                  <tr>
                    <td><?php echo htmlspecialchars($row['sample_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['requested_by']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($row['type'])); ?></td>
                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                    <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars(ucfirst($status)); ?></span></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                  </tr>
                <?php endforeach; ?>
                <?php if (!$rows): ?>
                  <tr>
                    <td colspan="6" class="text-center text-muted py-3">No sample orders found.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
