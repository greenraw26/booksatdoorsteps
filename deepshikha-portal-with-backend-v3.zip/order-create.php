<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require __DIR__ . '/backend/config.php';

$errors = [];
$success = null;

function generate_order_no() {
    return 'ORD-' . date('Ymd-His');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $school_name    = trim($_POST['school_name'] ?? '');
    $city           = trim($_POST['city'] ?? '');
    $state          = trim($_POST['state'] ?? '');
    $status         = $_POST['status'] ?? 'pending_ack';
    $booking_date   = $_POST['booking_date'] ?? date('Y-m-d');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $mobile         = trim($_POST['mobile'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $notes          = trim($_POST['notes'] ?? '');

    if ($school_name === '') $errors[] = "School / Partner name is required.";
    if ($city === '')        $errors[] = "City is required.";
    if ($state === '')       $errors[] = "State is required.";

    $items = $_POST['items'] ?? [];
    $cleanItems = [];

    if (is_array($items)) {
        foreach ($items as $row) {
            $title = trim($row['title'] ?? '');
            $class = trim($row['class'] ?? '');
            $qty   = (int)($row['qty'] ?? 0);
            $rate  = (float)($row['rate'] ?? 0);

            if ($title !== '' && $qty > 0) {
                $cleanItems[] = [
                    'title' => $title,
                    'class' => $class,
                    'qty'   => $qty,
                    'rate'  => $rate,
                ];
            }
        }
    }

    if (empty($cleanItems)) {
        $errors[] = "Add at least one title with quantity.";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $order_no = generate_order_no();

            $stmt = $pdo->prepare("
                INSERT INTO orders (order_no, school_name, city, state, status, booking_date, contact_person, mobile, email, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $order_no,
                $school_name,
                $city,
                $state,
                $status,
                $booking_date,
                $contact_person,
                $mobile,
                $email,
                $notes,
            ]);

            $order_id = $pdo->lastInsertId();

            $stmtItem = $pdo->prepare("
                INSERT INTO order_items (order_id, title, class, qty, rate)
                VALUES (?, ?, ?, ?, ?)
            ");

            foreach ($cleanItems as $ci) {
                $stmtItem->execute([
                    $order_id,
                    $ci['title'],
                    $ci['class'],
                    $ci['qty'],
                    $ci['rate'],
                ]);
            }

            $pdo->commit();
            $success = "Order created successfully with Order No: " . htmlspecialchars($order_no);
            $school_name = $city = $state = $contact_person = $mobile = $email = $notes = "";
            $status = "pending_ack";
            $booking_date = date('Y-m-d');
            $cleanItems = [];
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Failed to save order. Please try again.";
        }
    }
} else {
    $school_name = $city = $state = $contact_person = $mobile = $email = $notes = "";
    $status = "pending_ack";
    $booking_date = date('Y-m-d');
    $cleanItems = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Create Order – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="d-flex dashboard-shell">
    <nav class="flex-shrink-0 p-3 border-end min-vh-100 sidebar">
      <a href="dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none sidebar-brand">
        <span class="brand-badge me-2">DD</span>
        <span class="fs-6 fw-bold">Deepshikha</span>
      </a>
      <hr />
      <ul class="nav nav-pills flex-column mb-auto small">
        <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
        <li><a href="orders-list.php" class="nav-link active">Orders</a></li>
        <li><a href="sample-orders.php" class="nav-link">Sample Orders</a></li>
      </ul>
      <hr />
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle small" data-bs-toggle="dropdown">
          <span class="me-2 avatar-circle"><?php echo strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?></span>
          <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin User'); ?></strong>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <main class="p-4 flex-grow-1 main-panel">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h1 class="h5 fw-bold mb-1">Create New Order</h1>
          <p class="small text-muted mb-0">Order booking with item lines</p>
        </div>
        <a href="orders-list.php" class="btn btn-outline-primary btn-sm rounded-pill">← Back to Orders</a>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger small">
          <ul class="mb-0">
            <?php foreach ($errors as $e): ?>
              <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert alert-success small">
          <?php echo $success; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="order-create.php">
        <div class="row g-3">
          <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <h2 class="h6 mb-3">Order Information</h2>
                <div class="row g-2">
                  <div class="col-md-6">
                    <label class="form-label">School / Partner <span class="text-danger">*</span></label>
                    <input type="text" name="school_name" class="form-control form-control-sm" value="<?php echo htmlspecialchars($school_name); ?>" required />
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">City <span class="text-danger">*</span></label>
                    <input type="text" name="city" class="form-control form-control-sm" value="<?php echo htmlspecialchars($city); ?>" required />
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">State <span class="text-danger">*</span></label>
                    <input type="text" name="state" class="form-control form-control-sm" value="<?php echo htmlspecialchars($state); ?>" required />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Booking Date</label>
                    <input type="date" name="booking_date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($booking_date); ?>" />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select form-select-sm">
                      <option value="pending_ack" <?php echo $status==='pending_ack'?'selected':''; ?>>Pending Ack.</option>
                      <option value="in_process" <?php echo $status==='in_process'?'selected':''; ?>>In Process</option>
                      <option value="processed" <?php echo $status==='processed'?'selected':''; ?>>Processed</option>
                    </select>
                  </div>
                </div>
                <hr />
                <div class="row g-2">
                  <div class="col-md-4">
                    <label class="form-label">Contact Person</label>
                    <input type="text" name="contact_person" class="form-control form-control-sm" value="<?php echo htmlspecialchars($contact_person); ?>" />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Mobile</label>
                    <input type="text" name="mobile" class="form-control form-control-sm" value="<?php echo htmlspecialchars($mobile); ?>" />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control form-control-sm" value="<?php echo htmlspecialchars($email); ?>" />
                  </div>
                </div>
              </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <h2 class="h6 mb-0">Order Lines</h2>
                  <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" id="add-item-row">+ Add Row</button>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm align-middle mb-0" id="items-table">
                    <thead class="table-light">
                      <tr>
                        <th style="width:5%;">Sr</th>
                        <th>Title</th>
                        <th style="width:15%;">Class</th>
                        <th style="width:15%;">Qty</th>
                        <th style="width:15%;">Rate</th>
                        <th style="width:5%;"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $index = 0;
                      if (!empty($cleanItems)) {
                          foreach ($cleanItems as $ci):
                      ?>
                        <tr>
                          <td class="text-muted align-middle"><?php echo $index+1; ?></td>
                          <td><input type="text" name="items[<?php echo $index; ?>][title]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['title']); ?>" /></td>
                          <td><input type="text" name="items[<?php echo $index; ?>][class]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['class']); ?>" /></td>
                          <td><input type="number" min="1" name="items[<?php echo $index; ?>][qty]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['qty']); ?>" /></td>
                          <td><input type="number" step="0.01" name="items[<?php echo $index; ?>][rate]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['rate']); ?>" /></td>
                          <td class="text-center align-middle">
                            <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
                          </td>
                        </tr>
                      <?php
                          $index++;
                          endforeach;
                      } else {
                      ?>
                        <tr>
                          <td class="text-muted align-middle">1</td>
                          <td><input type="text" name="items[0][title]" class="form-control form-control-sm" /></td>
                          <td><input type="text" name="items[0][class]" class="form-control form-control-sm" /></td>
                          <td><input type="number" min="1" name="items[0][qty]" class="form-control form-control-sm" /></td>
                          <td><input type="number" step="0.01" name="items[0][rate]" class="form-control form-control-sm" /></td>
                          <td class="text-center align-middle">
                            <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <p class="small text-muted mt-2 mb-0">
                  Only rows with a Title and Qty &gt; 0 will be saved.
                </p>
              </div>
            </div>
          </div>

          <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <h2 class="h6 mb-3">Notes</h2>
                <textarea name="notes" class="form-control form-control-sm" rows="6" placeholder="Internal notes (not printed on invoice)"><?php echo htmlspecialchars($notes); ?></textarea>
              </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4">
              <div class="card-body small d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-semibold">Save Order</div>
                  <div class="text-muted small">Order No will be auto‑generated.</div>
                </div>
                <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4">Save</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    (function() {
      const tableBody = document.querySelector('#items-table tbody');
      const addBtn = document.getElementById('add-item-row');

      function currentIndex() {
        return tableBody.querySelectorAll('tr').length;
      }

      if (addBtn) {
        addBtn.addEventListener('click', function() {
          const index = currentIndex();
          const row = document.createElement('tr');
          row.innerHTML = `
            <td class="text-muted align-middle">${index + 1}</td>
            <td><input type="text" name="items[${index}][title]" class="form-control form-control-sm" /></td>
            <td><input type="text" name="items[${index}][class]" class="form-control form-control-sm" /></td>
            <td><input type="number" min="1" name="items[${index}][qty]" class="form-control form-control-sm" /></td>
            <td><input type="number" step="0.01" name="items[${index}][rate]" class="form-control form-control-sm" /></td>
            <td class="text-center align-middle">
              <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
            </td>
          `;
          tableBody.appendChild(row);
        });
      }

      tableBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-row')) {
          const rows = tableBody.querySelectorAll('tr');
          if (rows.length > 1) {
            e.target.closest('tr').remove();
          }
        }
      });
    })();
  </script>
</body>
</html>
