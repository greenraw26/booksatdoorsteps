-- Deepshikha Portal schema
CREATE DATABASE IF NOT EXISTS deepshikha_portal
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE deepshikha_portal;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','sales','school','parent') NOT NULL DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(50) NOT NULL UNIQUE,
  school_name VARCHAR(200) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  status ENUM('pending_ack','in_process','processed') NOT NULL DEFAULT 'pending_ack',
  booking_date DATE NOT NULL,
  contact_person VARCHAR(120),
  mobile VARCHAR(20),
  email VARCHAR(150),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  class VARCHAR(50),
  qty INT NOT NULL,
  rate DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sample_orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sample_no VARCHAR(50) NOT NULL UNIQUE,
  requested_by VARCHAR(200) NOT NULL,
  type ENUM('school','parent') NOT NULL DEFAULT 'school',
  city VARCHAR(100),
  status ENUM('pending','dispatched','delivered') NOT NULL DEFAULT 'pending',
  created_at DATE NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sample_order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sample_order_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  class VARCHAR(50),
  qty INT NOT NULL,
  CONSTRAINT fk_sample_items_sample FOREIGN KEY (sample_order_id) REFERENCES sample_orders(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS stores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  state VARCHAR(100) NOT NULL,
  city VARCHAR(100) NOT NULL,
  vendor_name VARCHAR(200) NOT NULL,
  contact_person VARCHAR(120),
  phone VARCHAR(20),
  address VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS resources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  category VARCHAR(100),
  type VARCHAR(50),
  audience VARCHAR(100),
  file_path VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS careers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  position VARCHAR(200) NOT NULL,
  location VARCHAR(200),
  type VARCHAR(50),
  status ENUM('active','closed') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS job_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  applicant_name VARCHAR(200) NOT NULL,
  applied_for VARCHAR(200) NOT NULL,
  city VARCHAR(100),
  mobile VARCHAR(20),
  status ENUM('new','in_review','shortlisted','rejected') NOT NULL DEFAULT 'new',
  acknowledgement_sent TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conditions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(100) NOT NULL UNIQUE,
  title VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Seed admin user: admin@example.com / admin123
INSERT INTO users (name, email, password_hash, role)
VALUES (
  'Portal Admin',
  'admin@example.com',
  '$2y$10$0i8RGe3reRb3N2N7uVP7QuG1VHYfdeYhwzE/SlpqU0OC8qFBrgXFe',
  'admin'
)
ON DUPLICATE KEY UPDATE email = email;

-- Seed demo orders
INSERT INTO orders (order_no, school_name, city, state, status, booking_date, contact_person, mobile, email)
VALUES
('ORD-2025-00123', 'ABC Public School', 'Delhi', 'Delhi', 'processed', '2025-12-09', 'Mr. Kumar', '9999999999', 'example@school.com'),
('ORD-2025-00124', 'XYZ International', 'Mumbai', 'Maharashtra', 'pending_ack', '2025-12-09', 'Ms. Rao', '9888888888', 'info@xyzschool.com'),
('ORD-2025-00125', 'Sample Distributor', 'Jaipur', 'Rajasthan', 'in_process', '2025-12-08', 'Mr. Singh', '9777777777', 'sales@sampledist.com')
ON DUPLICATE KEY UPDATE school_name = school_name;

INSERT INTO order_items (order_id, title, class, qty, rate)
SELECT id, 'English Reader', 'Class 1', 50, 120.00 FROM orders WHERE order_no='ORD-2025-00123'
UNION ALL
SELECT id, 'Math Workbook', 'Class 1', 50, 110.00 FROM orders WHERE order_no='ORD-2025-00123';

-- Seed sample orders
INSERT INTO sample_orders (sample_no, requested_by, type, city, status, created_at)
VALUES
('SMP-2025-0001', 'ABC Public School', 'school', 'Delhi', 'dispatched', '2025-12-01'),
('SMP-2025-0002', 'Parent Walk-in', 'parent', 'Jaipur', 'pending', '2025-12-05')
ON DUPLICATE KEY UPDATE requested_by = requested_by;

-- Seed stores
INSERT INTO stores (state, city, vendor_name, contact_person, phone, address) VALUES
('Delhi', 'New Delhi', 'ABC Book Depot', 'Mr. Sharma', '9800000001', 'Karol Bagh, New Delhi'),
('Maharashtra', 'Mumbai', 'Bright Kids Store', 'Ms. Rao', '9800000002', 'Andheri West, Mumbai')
ON DUPLICATE KEY UPDATE vendor_name = vendor_name;

-- Seed conditions
INSERT INTO conditions (slug, title, body)
VALUES
('orders-and-samples', 'Order & Sample Terms', 'Replace this with your actual order, payment and sample policies.')
ON DUPLICATE KEY UPDATE title = VALUES(title);
