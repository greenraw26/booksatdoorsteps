DEEPSHIKHA PORTAL – BACKEND QUICK SETUP
========================================

This package contains:
- Frontend UI (child‑centric, responsive, Bootstrap)
- PHP + MySQL backend starter
- Dynamic modules for Orders and Sample Orders (create + list)

Files of interest
-----------------
backend/config.php   -> Database connection (edit credentials here)
backend/db.sql       -> Database schema + sample data (import into MySQL)

login.php            -> Login form using `users` table
dashboard.php        -> Dashboard with recent orders
orders-list.php      -> Orders listing from `orders` table
order-create.php     -> Dynamic Create Order (header + item lines)
sample-orders.php    -> Sample Orders listing from `sample_orders` table
sample-order-create.php -> Dynamic Create Sample Order

Quick start (XAMPP)
-------------------
1. Copy this whole folder to:
   C:\xampp\htdocs\deepshikha-portal

2. Start Apache and MySQL in XAMPP.

3. Open phpMyAdmin and import backend/db.sql

4. Make sure backend/config.php matches your DB credentials.
   Default in XAMPP: user `root`, no password.

5. Visit in your browser:
   http://localhost/deepshikha-portal/login.php

6. Login with:
   Email:    admin@example.com
   Password: admin123

Then navigate to:
- Orders -> see Manage Orders and Create Order
- Sample Orders -> see list and create screen

Your developer can extend every module using these patterns.
