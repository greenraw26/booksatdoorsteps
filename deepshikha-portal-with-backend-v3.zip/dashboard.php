<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require __DIR__ . '/backend/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="d-flex dashboard-shell">
    <nav class="flex-shrink-0 p-3 border-end min-vh-100 sidebar">
      <a href="dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none sidebar-brand">
        <span class="brand-badge me-2">DD</span>
        <span class="fs-6 fw-bold">Deepshikha</span>
      </a>
      <hr />
      <ul class="nav nav-pills flex-column mb-auto small">
        <li class="nav-item">
          <a href="dashboard.php" class="nav-link active">Dashboard</a>
        </li>
        <li><a href="orders-list.php" class="nav-link">Orders</a></li>
        <li><a href="sample-orders.php" class="nav-link">Sample Orders</a></li>
      </ul>
      <hr />
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle small" data-bs-toggle="dropdown">
          <span class="me-2 avatar-circle"><?php echo strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?></span>
          <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin User'); ?></strong>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <main class="p-4 flex-grow-1 main-panel">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h1 class="h4 fw-bold mb-1">Dashboard</h1>
          <p class="small text-muted mb-0">Welcome, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?>.</p>
        </div>
        <span class="badge bg-primary-subtle text-primary">Demo: Orders + Sample Orders</span>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-3">
          <div class="card border-0 shadow-sm rounded-4 stat-card">
            <div class="card-body">
              <div class="small text-muted">Orders Today</div>
              <div class="fs-4 fw-bold">128</div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card border-0 shadow-sm rounded-4 stat-card">
            <div class="card-body">
              <div class="small text-muted">Sample Orders</div>
              <div class="fs-4 fw-bold">32</div>
            </div>
          </div>
        </div>
      </div>

      <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h2 class="h6 mb-0">Recent Orders (from DB)</h2>
            <a href="orders-list.php" class="btn btn-sm btn-outline-primary rounded-pill">View all</a>
          </div>
          <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th>Order No.</th>
                  <th>School / Partner</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Booking Date</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $stmt = $pdo->query("SELECT order_no, school_name, city, status, booking_date FROM orders ORDER BY booking_date DESC, id DESC LIMIT 5");
                foreach ($stmt as $row):
                    $status = $row['status'];
                    $badgeClass = 'bg-secondary-subtle text-secondary';
                    if ($status === 'processed') $badgeClass = 'bg-success-subtle text-success';
                    elseif ($status === 'in_process') $badgeClass = 'bg-primary-subtle text-primary';
                    elseif ($status === 'pending_ack') $badgeClass = 'bg-warning-subtle text-warning';
                ?>
                  <tr>
                    <td><?php echo htmlspecialchars($row['order_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['school_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                    <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $status))); ?></span></td>
                    <td><?php echo htmlspecialchars($row['booking_date']); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <h2 class="h6 mb-0">Recent Sample Orders</h2>
            <a href="sample-orders.php" class="btn btn-sm btn-outline-primary rounded-pill">View all</a>
          </div>
          <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th>Sample No.</th>
                  <th>Requested By</th>
                  <th>Type</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $stmt2 = $pdo->query("SELECT sample_no, requested_by, type, city, status, created_at FROM sample_orders ORDER BY created_at DESC, id DESC LIMIT 5");
                foreach ($stmt2 as $row):
                    $status = $row['status'];
                    $badgeClass = 'bg-secondary-subtle text-secondary';
                    if ($status === 'delivered') $badgeClass = 'bg-success-subtle text-success';
                    elseif ($status === 'dispatched') $badgeClass = 'bg-primary-subtle text-primary';
                    elseif ($status === 'pending') $badgeClass = 'bg-warning-subtle text-warning';
                ?>
                  <tr>
                    <td><?php echo htmlspecialchars($row['sample_no']); ?></td>
                    <td><?php echo htmlspecialchars($row['requested_by']); ?></td>
                    <td><?php echo htmlspecialchars(ucfirst($row['type'])); ?></td>
                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                    <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars(ucfirst($status)); ?></span></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
