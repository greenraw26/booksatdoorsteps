<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require __DIR__ . '/backend/config.php';

$errors = [];
$success = null;

function generate_sample_no() {
    return 'SMP-' . date('Ymd-His');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $requested_by = trim($_POST['requested_by'] ?? '');
    $type         = $_POST['type'] ?? 'school';
    $city         = trim($_POST['city'] ?? '');
    $status       = $_POST['status'] ?? 'pending';
    $created_at   = $_POST['created_at'] ?? date('Y-m-d');

    if ($requested_by === '') $errors[] = "Requested By is required.";
    if ($city === '')         $errors[] = "City is required.";

    $items = $_POST['items'] ?? [];
    $cleanItems = [];

    if (is_array($items)) {
        foreach ($items as $row) {
            $title = trim($row['title'] ?? '');
            $class = trim($row['class'] ?? '');
            $qty   = (int)($row['qty'] ?? 0);
            if ($title !== '' && $qty > 0) {
                $cleanItems[] = [
                    'title' => $title,
                    'class' => $class,
                    'qty'   => $qty,
                ];
            }
        }
    }

    if (empty($cleanItems)) {
        $errors[] = "Add at least one title with quantity.";
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $sample_no = generate_sample_no();

            $stmt = $pdo->prepare("
                INSERT INTO sample_orders (sample_no, requested_by, type, city, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $sample_no,
                $requested_by,
                $type,
                $city,
                $status,
                $created_at,
            ]);

            $sample_id = $pdo->lastInsertId();

            $stmtItem = $pdo->prepare("
                INSERT INTO sample_order_items (sample_order_id, title, class, qty)
                VALUES (?, ?, ?, ?)
            ");

            foreach ($cleanItems as $ci) {
                $stmtItem->execute([
                    $sample_id,
                    $ci['title'],
                    $ci['class'],
                    $ci['qty'],
                ]);
            }

            $pdo->commit();
            $success = "Sample order created successfully with Sample No: " . htmlspecialchars($sample_no);
            $requested_by = $city = "";
            $type = "school";
            $status = "pending";
            $created_at = date('Y-m-d');
            $cleanItems = [];
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Failed to save sample order. Please try again.";
        }
    }
} else {
    $requested_by = $city = "";
    $type = "school";
    $status = "pending";
    $created_at = date('Y-m-d');
    $cleanItems = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Create Sample Order – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="d-flex dashboard-shell">
    <nav class="flex-shrink-0 p-3 border-end min-vh-100 sidebar">
      <a href="dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none sidebar-brand">
        <span class="brand-badge me-2">DD</span>
        <span class="fs-6 fw-bold">Deepshikha</span>
      </a>
      <hr />
      <ul class="nav nav-pills flex-column mb-auto small">
        <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
        <li><a href="orders-list.php" class="nav-link">Orders</a></li>
        <li><a href="sample-orders.php" class="nav-link active">Sample Orders</a></li>
      </ul>
      <hr />
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle small" data-bs-toggle="dropdown">
          <span class="me-2 avatar-circle"><?php echo strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?></span>
          <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin User'); ?></strong>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <main class="p-4 flex-grow-1 main-panel">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h1 class="h5 fw-bold mb-1">Create Sample Order</h1>
          <p class="small text-muted mb-0">School / parent sample request</p>
        </div>
        <a href="sample-orders.php" class="btn btn-outline-primary btn-sm rounded-pill">← Back to Sample Orders</a>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger small">
          <ul class="mb-0">
            <?php foreach ($errors as $e): ?>
              <li><?php echo htmlspecialchars($e); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="alert alert-success small">
          <?php echo $success; ?>
        </div>
      <?php endif; ?>

      <form method="post" action="sample-order-create.php">
        <div class="row g-3">
          <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <h2 class="h6 mb-3">Request Details</h2>
                <div class="row g-2">
                  <div class="col-md-6">
                    <label class="form-label">Requested By <span class="text-danger">*</span></label>
                    <input type="text" name="requested_by" class="form-control form-control-sm" value="<?php echo htmlspecialchars($requested_by); ?>" required />
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select form-select-sm">
                      <option value="school" <?php echo $type==='school'?'selected':''; ?>>School</option>
                      <option value="parent" <?php echo $type==='parent'?'selected':''; ?>>Parent</option>
                    </select>
                  </div>
                  <div class="col-md-3">
                    <label class="form-label">City <span class="text-danger">*</span></label>
                    <input type="text" name="city" class="form-control form-control-sm" value="<?php echo htmlspecialchars($city); ?>" required />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Request Date</label>
                    <input type="date" name="created_at" class="form-control form-control-sm" value="<?php echo htmlspecialchars($created_at); ?>" />
                  </div>
                  <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select form-select-sm">
                      <option value="pending" <?php echo $status==='pending'?'selected':''; ?>>Pending</option>
                      <option value="dispatched" <?php echo $status==='dispatched'?'selected':''; ?>>Dispatched</option>
                      <option value="delivered" <?php echo $status==='delivered'?'selected':''; ?>>Delivered</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <h2 class="h6 mb-0">Sample Titles</h2>
                  <button type="button" class="btn btn-outline-primary btn-sm rounded-pill" id="add-sample-row">+ Add Row</button>
                </div>
                <div class="table-responsive">
                  <table class="table table-sm align-middle mb-0" id="sample-items-table">
                    <thead class="table-light">
                      <tr>
                        <th style="width:5%;">Sr</th>
                        <th>Title</th>
                        <th style="width:20%;">Class</th>
                        <th style="width:20%;">Qty</th>
                        <th style="width:5%;"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $index = 0;
                      if (!empty($cleanItems)) {
                          foreach ($cleanItems as $ci):
                      ?>
                        <tr>
                          <td class="text-muted align-middle"><?php echo $index+1; ?></td>
                          <td><input type="text" name="items[<?php echo $index; ?>][title]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['title']); ?>" /></td>
                          <td><input type="text" name="items[<?php echo $index; ?>][class]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['class']); ?>" /></td>
                          <td><input type="number" min="1" name="items[<?php echo $index; ?>][qty]" class="form-control form-control-sm" value="<?php echo htmlspecialchars($ci['qty']); ?>" /></td>
                          <td class="text-center align-middle">
                            <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
                          </td>
                        </tr>
                      <?php
                          $index++;
                          endforeach;
                      } else {
                      ?>
                        <tr>
                          <td class="text-muted align-middle">1</td>
                          <td><input type="text" name="items[0][title]" class="form-control form-control-sm" /></td>
                          <td><input type="text" name="items[0][class]" class="form-control form-control-sm" /></td>
                          <td><input type="number" min="1" name="items[0][qty]" class="form-control form-control-sm" /></td>
                          <td class="text-center align-middle">
                            <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <p class="small text-muted mt-2 mb-0">
                  Only rows with a Title and Qty &gt; 0 will be saved.
                </p>
              </div>
            </div>
          </div>

          <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4 mb-3">
              <div class="card-body small">
                <h2 class="h6 mb-3">Internal Notes</h2>
                <p class="small text-muted mb-0">
                  Your developer can add more fields here later (dispatch details, courier, docket no., etc.).
                </p>
              </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4">
              <div class="card-body small d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-semibold">Save Sample Order</div>
                  <div class="text-muted small">Sample No will be auto‑generated.</div>
                </div>
                <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4">Save</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </main>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    (function() {
      const tableBody = document.querySelector('#sample-items-table tbody');
      const addBtn = document.getElementById('add-sample-row');

      function currentIndex() {
        return tableBody.querySelectorAll('tr').length;
      }

      if (addBtn) {
        addBtn.addEventListener('click', function() {
          const index = currentIndex();
          const row = document.createElement('tr');
          row.innerHTML = `
            <td class="text-muted align-middle">${index + 1}</td>
            <td><input type="text" name="items[${index}][title]" class="form-control form-control-sm" /></td>
            <td><input type="text" name="items[${index}][class]" class="form-control form-control-sm" /></td>
            <td><input type="number" min="1" name="items[${index}][qty]" class="form-control form-control-sm" /></td>
            <td class="text-center align-middle">
              <button type="button" class="btn btn-link btn-sm text-danger remove-row">&times;</button>
            </td>
          `;
          tableBody.appendChild(row);
        });
      }

      tableBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-row')) {
          const rows = tableBody.querySelectorAll('tr');
          if (rows.length > 1) {
            e.target.closest('tr').remove();
          }
        }
      });
    })();
  </script>
</body>
</html>
