<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
require __DIR__ . '/backend/config.php';

$status_filter = $_GET['status'] ?? 'all';

$sql = "SELECT * FROM orders";
$params = [];
if ($status_filter !== 'all') {
    $sql .= " WHERE status = ?";
    $params[] = $status_filter;
}
$sql .= " ORDER BY booking_date DESC, id DESC LIMIT 200";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Orders – Deepshikha Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
  <div class="d-flex dashboard-shell">
    <nav class="flex-shrink-0 p-3 border-end min-vh-100 sidebar">
      <a href="dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none sidebar-brand">
        <span class="brand-badge me-2">DD</span>
        <span class="fs-6 fw-bold">Deepshikha</span>
      </a>
      <hr />
      <ul class="nav nav-pills flex-column mb-auto small">
        <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
        <li><a href="orders-list.php" class="nav-link active">Orders</a></li>
        <li><a href="sample-orders.php" class="nav-link">Sample Orders</a></li>
      </ul>
      <hr />
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle small" data-bs-toggle="dropdown">
          <span class="me-2 avatar-circle"><?php echo strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 1)); ?></span>
          <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin User'); ?></strong>
        </a>
        <ul class="dropdown-menu text-small shadow">
          <li><a class="dropdown-item" href="#">Profile</a></li>
          <li><a class="dropdown-item" href="#">Settings</a></li>
          <li><hr class="dropdown-divider" /></li>
          <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
        </ul>
      </div>
    </nav>

    <main class="p-4 flex-grow-1 main-panel">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h1 class="h5 fw-bold mb-1">Manage Orders</h1>
          <p class="small text-muted mb-0">Orders from MySQL database</p>
        </div>
        <a href="order-create.php" class="btn btn-primary btn-sm rounded-pill">+ New Order</a>
      </div>

      <div class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body small">
          <form class="row g-2 align-items-end" method="get" action="orders-list.php">
            <div class="col-md-3">
              <label class="form-label">Status</label>
              <select name="status" class="form-select form-select-sm">
                <option value="all" <?php echo $status_filter==='all'?'selected':''; ?>>All</option>
                <option value="pending_ack" <?php echo $status_filter==='pending_ack'?'selected':''; ?>>Pending Ack.</option>
                <option value="in_process" <?php echo $status_filter==='in_process'?'selected':''; ?>>In Process</option>
                <option value="processed" <?php echo $status_filter==='processed'?'selected':''; ?>>Processed</option>
              </select>
            </div>
            <div class="col-md-2">
              <button class="btn btn-outline-primary btn-sm rounded-pill w-100" type="submit">Filter</button>
            </div>
          </form>
        </div>
      </div>

      <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-sm align-middle mb-0 small">
              <thead class="table-light">
                <tr>
                  <th>Order No.</th>
                  <th>School / Partner</th>
                  <th>City</th>
                  <th>Status</th>
                  <th>Booking Date</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($orders as $order):
                    $status = $order['status'];
                    $badgeClass = 'bg-secondary-subtle text-secondary';
                    if ($status === 'processed') $badgeClass = 'bg-success-subtle text-success';
                    elseif ($status === 'in_process') $badgeClass = 'bg-primary-subtle text-primary';
                    elseif ($status === 'pending_ack') $badgeClass = 'bg-warning-subtle text-warning';
                ?>
                  <tr>
                    <td><?php echo htmlspecialchars($order['order_no']); ?></td>
                    <td><?php echo htmlspecialchars($order['school_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['city']); ?></td>
                    <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars(ucwords(str_replace('_',' ', $status))); ?></span></td>
                    <td><?php echo htmlspecialchars($order['booking_date']); ?></td>
                  </tr>
                <?php endforeach; ?>
                <?php if (!$orders): ?>
                  <tr>
                    <td colspan="5" class="text-center text-muted py-3">No orders found.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
